Clientul primeste ca si parametri in linia de comanda:
-username
-parola
-cheia de criptare pentru sesiunea curenta