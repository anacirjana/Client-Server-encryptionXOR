#include <Windows.h>
#include <stdio.h>
HANDLE handle;	
DWORD length;
DWORD WaitTime = 100000000;
char users[20][20] = { "ana","user1","col1" }, passwords[20][20] = { "ana","pass","col1" };
char key[20];
DWORD usersN = 3;
char pack[250],crypted[250];
int c = 0;
int contentSize, keySize;

BOOL Verify(char username[],char password[])
{
	for (int i = 0; i < usersN; i++)
	{
		if (!strcmp(username, users[i]) && !strcmp(password, passwords[i]))
			return 1;
	}
	return 0;
}
int getSize(int start)
{
	int nr = 0;
	for (int i = start; i <= start+3; i++)
	{
		nr = nr * 10 + pack[i]-'0';
	}
	return nr;
}
void crypt(int start)
{
	int kCurs = 0;
	for (int i = start; i < contentSize + start; i++)
	{
		if (kCurs == keySize)
		{
			kCurs = 0;
		}
		crypted[c] = (int)key[kCurs] ^ (int)pack[i];
		if (crypted[c] == 0) //NULL, endofeverything
		{
			crypted[c] = 32;
		}

		kCurs++;
		c++;
	}
	
}
void init()
{
	handle = CreateNamedPipe(
		"\\\\.\\pipe\\MyPipe",
		PIPE_ACCESS_DUPLEX,
		PIPE_WAIT,
		PIPE_UNLIMITED_INSTANCES,
		4096,
		4096,
		WaitTime,
		NULL
	);
}
int main()
{
	init();
	length = 250;
	while (1)
	{
		BOOL res = ConnectNamedPipe(
			handle,
			NULL
		);
		//WaitNamedPipeA(handle, WaitTime);
		if (res)
		{
			printf("%s", "Connected!\n");

			memset(pack, 0, 250);
			res = ReadFile(handle, pack, 8, &length, NULL); //8=length of the first package
			pack[length] = 0;
			if (pack[0] == '0')
			{
				memset(pack, 0, 250);
				res = ReadFile(handle, pack, 250, &length, NULL); 
				
				
				//calculate size:
				int size=0;
				for (int i = 1; i <= 4; i++)
				{
					size = size * 10 + pack[i] - '0';
				}
				int i = 1,u=1,k=0,l=0;
				char username[20], password[20];
				for (i = 5; i < 5+size; i++) 
				{
					if (pack[i] == '|')
						u = 0;
					else
					if (u == 1)
						username[k++] = pack[i];
					else
						password[l++] = pack[i];
				}
				username[k] = 0;
				password[l] = 0;
				if (Verify(username, password))
				{
					printf("Authentified! Username: %s\n", username); 
					memset(pack, 0, 250);
					res = ReadFile(handle, pack, 250, &length, NULL);
					int cursor = 0;
					keySize = getSize(cursor);
					cursor = 4;
					int m = 0;
					for (int j = cursor; j < keySize + cursor; j++)
					{
						key[m++] = pack[j];
					}
					cursor += keySize;
					contentSize = getSize(cursor);
					cursor += 4;
					printf("\nKey Size:%d, Content Size:%d",keySize,contentSize);
					crypt(cursor);
					printf("\nCrypted:\n%s\n", crypted);
					//send to client:
					res = WriteFile(handle,
						crypted,
						c,
						&length,
						NULL
					);
					//return res;

				}
				else
				{
					printf("Authentification failed!\n");
				}
				
				
				
			}

			//goto CleanUp;
		}
		else
		{
			//printf("%s", "Else");
		}

		// Exit if an error other than ERROR_PIPE_BUSY occurs. 

		if (GetLastError() == ERROR_PIPE_CONNECTED)
		{
			printf("%s%d","Could not open pipe. GLE=\n", GetLastError());
			return -1;
		}

		// All pipe instances are busy, so wait for 20 seconds. 
		/*
		if (!WaitNamedPipe("\\\\.\\pipe\\MyPipe", 20000))
		{
			printf("Could not open pipe: 20 second wait timed out.");
			return -1;
		}*/

		DisconnectNamedPipe(handle);

//		CloseHandle(handle);
	
}
	
CleanUp:
	getchar();
	CloseHandle(handle);

}