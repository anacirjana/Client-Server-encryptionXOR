#include <stdio.h>
#include <Windows.h>
#include <string.h>
HANDLE handle;
HANDLE file;

char message[100],pack[250], username[20], password[20],key[20];
DWORD length=60;
BOOL SendFirstPackage()
{
	strncpy_s(pack, 10, "00000000\0", 250);
	DWORD len = 3;
	BOOL res;
	res = WriteFile(handle,
		pack,
		8,
		&len,
		NULL
	);
	return res;
}
BOOL SendAuthentificationPackage()
{
	length = 60;
	memset(pack, 0, 250);
	strncpy_s(pack, 2, "1", 250);
	DWORD lenu = strlen(username), lenp = strlen(password);
	DWORD size=1;
	size += lenu + lenp;
	//4 chars reserved for the size of the package
	char csize[4];
	memset(csize, '0', 4);
	strcat_s(pack, 250, csize);
	int nrc = 0;
	int s = size;
	while (s)
	{
		pack[4 - nrc] = s % 10 + 48;
		s /= 10;
		nrc++;
	}
	pack[5] = 0;

	strcat_s(pack, 250, username);

	char t[3];
	memset(t, 0, 3); 
	t[0]= '|';
	strcat_s(pack, 250, t);
	
	strcat_s(pack, 250, password);

	//effectively send:
	BOOL res;

	size++;//for the first char
	res = WriteFile(handle,
		pack,
		size+4,
		&length,
		NULL
	);
	return res;

}
int SendFileContent()
{
	int bytesRead,size;
	size = strlen(key);
	char buf[220];
	int rez = ReadFile(
		file,
		buf,
		220,
		&bytesRead,
		NULL
	);
	buf[bytesRead] = 0;
	int res;//mai intai, size of the key
	char csize[5];
	memset(csize, '0', 4);
	csize[4] = 0;
	strcat_s(pack, 5, csize);
	strcat_s(pack, 20, key);
	pack[25] = 0;
	//acum size of the current buffer
	memset(csize, '0', 4);
	csize[4] = 0;
	strcat_s(pack, 250, csize);

	int nrc = 1;
	int s = size;
	while (s)
	{
		pack[4 - nrc] = s % 10 + 48;
		s /= 10;
		nrc++;
	}
	//pack[5] = 0;

	nrc = 1;
	s = bytesRead;
	while (s)
	{
		pack[size+8 - nrc] = s % 10 + 48;
		s /= 10;
		nrc++;
	}
	pack[size+9] = 0;

	strcat_s(pack, 250, buf);
	res = WriteFile(handle,
		pack,
		250,
		&length,
		NULL
	);
	return res;
}
int main(int argc, char* argv[])
{
	
	BOOL res;
	//length = 10;
	handle = CreateFileA(
		"\\\\.\\pipe\\MyPipe",
		GENERIC_READ | GENERIC_WRITE,
		0,
		NULL,
		OPEN_EXISTING,
		NULL,
		NULL
	);
	
	res = SendFirstPackage();
	if (!res)
	{
		//goto CleanUp;
		printf("%s","Not okay");
	}
	else
	{
		printf("%s","client connected!");
		
		if (res)
		{
			
			strcpy_s(username,20,argv[1]);
			strcpy_s(password,20,argv[2]);
			
			res = SendAuthentificationPackage();
			if (res)
			{
				//authentification successful
				file = CreateFileA(
					"C:\\Users\\Ana Cirjan\\Documents\\info\\Cerc C\\SEM 2\\ProjectV1\\Client\\Debug\\CriptIn.txt",
					GENERIC_READ,
					FILE_SHARE_READ,
					NULL,
					OPEN_EXISTING,
					NULL,
					NULL
				);
				//printf("GLE=%d", GetLastError());
				if (file == INVALID_HANDLE_VALUE)
				{
					printf("Nu ii bun handlerul");
				}
				else
				{
					
					//Sleep(1000);
					memset(pack, 0, 250);

					strcpy_s(key, 20, argv[3]);
					SendFileContent();
					memset(pack, 0, 250);
					res = ReadFile(handle, pack, 250, &length, NULL);
					//now we have the encrypted data
					HANDLE writeH = CreateFile(
						"CriptOut.txt",
						GENERIC_WRITE,
						0,
						NULL,
						CREATE_ALWAYS,
						FILE_ATTRIBUTE_NORMAL,
						NULL
					);
					int wll;
					res = WriteFile(writeH, pack, length, &wll,NULL);
					printf("%s", pack);
				}
			}
		}

	}
	
CleanUp:
	DisconnectNamedPipe(handle);
	CloseHandle(handle);

	getchar();
	return 0;
}